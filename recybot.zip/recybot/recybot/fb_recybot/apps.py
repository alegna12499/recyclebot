from django.apps import AppConfig


class FbRecybotConfig(AppConfig):
    name = 'fb_recybot'

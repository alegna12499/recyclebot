import json, requests, random, re
from pprint import pprint

from django.views import generic
from django.http.response import HttpResponse

from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

PAGE_ACCESS_TOKEN = "EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD"
VERIFY_TOKEN = "739545000"

def post_recyclable(fbid, recevied_message):
        tempInput = re.sub(r"[^a-zA-Z0-9\s]",' ',recevied_message).lower()

        infile = open("/Users/mariamahin/Documents/recybot/recybot/fb_recybot/items.txt","r")
        blueBin =[]
        greenBin = []
        trash = []
        special = []

        for line in infile:
            tempLine = line.split(",")
            if tempLine[0] == 'BlueBin':
                blueBin.append(tempLine[1])
            elif tempLine[0] == 'GreenBin':
                greenBin.append(tempLine[1])
            elif tempLine[0] == 'Trash':
                trash.append(tempLine[1])
            else:
                special.append(tempLine[1])

        infile.close()
        typeOfBin = 'Not Recyclable'
		
        for item in trash:
            if tempInput.find(item) != -1:
                typeOfBin = 'Trash'

        for item in blueBin:
            if tempInput.find(item) != -1:
                typeOfBin = 'Blue Bin'

        for item in greenBin:
            if tempInput.find(item) != -1:
                typeOfBin = 'Green Bin'

        for item in special:
            if tempInput.find(item) != -1:
                typeOfBin = 'Special'

        if typeOfBin == 'Trash' or typeOfBin == 'Not Recyclable':
            outputText = "This item is not recyclable :( . Please place it into a trash bin."
        elif typeOfBin == 'Blue Bin':
            outputText = "This item is recyclable! :D Please empty and rinse off your item and place it into a blue recycling bin."
        elif typeOfBin == 'Special':
            outputText = "There are special rules to dispose of this item. If you live in the NYC area, you can read more about them here: http://www1.nyc.gov/assets/dsny/zerowaste/residents/special-waste-drop-off-sites.shtml"
        else:
            outputText = "This item is recyclable! :D Please place your item into a green recycling bin. If it is soiled, place it into a trash bin."

        user_details_url = "https://graph.facebook.com/v2.6/%s"%fbid 
        user_details_params = {'fields':'first_name,last_name,profile_pic', 'access_token':'EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'} 
        user_details = requests.get(user_details_url, user_details_params).json()
        
        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": outputText}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())

        askAgain = "Please enter another item to check if it's recyclable, or ask me what else I can help you with!"
        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": askAgain}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())

def post_greeting(fbid):
        
        user_details_url = "https://graph.facebook.com/v2.6/%s"%fbid 
        user_details_params = {'fields':'first_name,last_name,profile_pic', 'access_token':'EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'} 
        user_details = requests.get(user_details_url, user_details_params).json()

        outputText = 'Hey ' + user_details['first_name']+ '! How can I help you today? \n \nYou can choose from options such as asking whether an item is recyclable, inquiring about NYC residential garage disposal practices, or asking for more links to helpful recycling information! '
        
        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": outputText}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())

def post_closing(fbid):

        user_details_url = "https://graph.facebook.com/v2.6/%s"%fbid 
        user_details_params = {'fields':'first_name,last_name,profile_pic', 'access_token':'EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'} 
        user_details = requests.get(user_details_url, user_details_params).json()
        
        outputText = "Bye " + user_details['first_name']+ "! Come back next time to ask another recycling related question! "
        
        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": outputText}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())

def handle_disposal_Request(fbid, messageType, item):
        
        infile = open("/Users/mariamahin/Documents/recybot/recybot/fb_recybot/disposalGuidelines.txt","r")

        paper = []
        plastic = []
        food = []
        electronics = []
        
        for line in infile:
                tempLine = line.split("|")
                if tempLine[0] == 'paper and cardboard':
                        paper.append(tempLine[1])
                elif tempLine[0] == 'metal glass plastic and cartons':
                        plastic.append(tempLine[1])
                elif tempLine[0] == 'food and food soiled paper':
                        food.append(tempLine[1])
                elif tempLine[0] == 'electronic waste':
                        electronics.append(tempLine[1])
        
        infile.close()
        
        if messageType == 'request':
                outputText = "Please enter one of these specific options to learn about residential disposal practices for that catergory: Paper and cardboard, Metal, glass, plastic and cartons, Food and food soiled paper, or Electronic waste"
        else:
                if item == 'paper and cardboard':
                        outputText = paper[0]
                elif item == 'metal glass plastic and cartons':
                        outputText = plastic[0]
                elif item == 'food and food soiled paper':
                        outputText = food[0]
                elif item == 'electronic waste':
                        outputText = electronics[0]
                        

        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": outputText}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())
               
def post_resources(fbid):

        outputText2 = "Here are some additional resources to check out: \n \n What can be recycled: \n http://www1.nyc.gov/assets/dsny/zerowaste/residents/what-to-recycle-for-residents.shtml"
        outputText3 = "Composting: \n https://www.grownyc.org/compost"
        outputText4 = "Why should you recycle?: \n https://www.grownyc.org/recycling/whyrecycle"
        
        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": outputText2}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())

        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": outputText3}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())

        post_message_url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAAc1vc2ZC7KUBAKRrfvHBZAkmfJqBZAt76sOvjMvwpyUqaWveJHgEEdZAL2ZBTh3Ufz9g9mA4rBkt2vo4qaQyJnzR68ceFTiefpFKZA7eLEGa6VdZAWTcSCFqyep28DXjybn3TZCgtMaZCYipgZBIByCVXwZB3iZA4jhjqKfqZApXHngKcgZDZD'
        response_msg = json.dumps({"recipient":{"id":fbid}, "message":{"text": outputText4}})
        status = requests.post(post_message_url, headers={"Content-Type": "application/json"},data=response_msg)
        pprint(status.json())
        
def handle_message(fbid, received_message):

        tokens = re.sub(r"[^a-zA-Z0-9\s]",' ',received_message).lower()
        

        isGreeting = False
        greetings = ['hello', 'hi', 'hey', 'welcome']

        isClosing = False
        closings = ['bye', 'goodbye', 'see you', 'done', 'finish', 'finished', 'nope', 'no', 'nah', 'thank', 'thanks']

        isDisposalRequest = False
        disposal = ['curbside', 'get rid of', 'dispose', 'disposal', 'residential', 'house', 'home', 'curb', 'remove']

        isDisposalChoice = False
        itemTypes = ['paper and cardboard', 'metal glass plastic and cartons', 'food and food soiled paper', 'electronic waste']

        isResources = False
        isResourceRequest = ['information', 'help', 'learn more about', 'resource', 'resources']
                            
        itemChoice = ''
        
        for item in itemTypes:
                if tokens.find(item) != -1:
                        isDisposalChoice = True
                        itemChoice = item
                        break

        if not isDisposalChoice:                       
                words = tokens.split()           
                for word in words:
                        if word in greetings:
                                isGreeting = True
                                break
                        if word in closings:
                                isClosing = True
                                break
                        if word in disposal:
                                isResources = False
                                isDisposalRequest = True
                                break
                        if word in isResourceRequest:
                                isResources = True
                                isDisposalRequest = False
                                break
        if isGreeting == True:
                post_greeting(fbid)
        elif isClosing == True:
                post_closing(fbid)
        elif isDisposalRequest == True:
                messageType = 'request'
                itemChoice = 'NULL'
                handle_disposal_Request(fbid, messageType, itemChoice)
        elif isDisposalChoice == True:
                messageType = 'choice'
                handle_disposal_Request(fbid, messageType, itemChoice)
        elif isResources == True:
                post_resources(fbid)
        else:
            post_recyclable(fbid, received_message)
    
# Create your views here.
class RecyBotView(generic.View):
	def get(self, request, *args, **kwargs):
		if self.request.GET['hub.verify_token'] == '739545000':
			return HttpResponse(self.request.GET['hub.challenge'])
		else:
			return HttpResponse('Error, invalid token')
		
	@method_decorator(csrf_exempt)
	def dispatch(self, request, *args, **kwargs):
		return generic.View.dispatch(self, request, *args, **kwargs)

	def post(self, request, *args, **kwargs):
                incoming_message = json.loads(self.request.body.decode('utf-8'))
		
                for entry in incoming_message['entry']:
                        for message in entry['messaging']:
                                if 'message' in message:
                                        pprint(message)
                                        handle_message(message['sender']['id'], message['message']['text'])    
		
                return HttpResponse()
